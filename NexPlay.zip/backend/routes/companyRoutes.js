const express = require("express");
const router = express.Router();

const authMiddleware = require("../middleware/authMiddleware");
const roleMiddleware = require("../middleware/roleMiddleware");

const {
  getMyCompany,
  updateMyCompany,
} = require("../controllers/companyController");

// Company Profile
router.get("/profile", authMiddleware, roleMiddleware("company"), getMyCompany);

router.put(
  "/profile",
  authMiddleware,
  roleMiddleware("company"),
  updateMyCompany,
);

module.exports = router;
