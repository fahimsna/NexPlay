const Company = require("../models/Company");

// GET LOGGED-IN COMPANY PROFILE
const getMyCompany = async (req, res) => {
  try {
    const company = await Company.findOne({
      ownerId: req.user.id,
    });

    if (!company) {
      return res.status(404).json({
        message: "Company profile not found",
      });
    }

    res.status(200).json({
      company,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// UPDATE LOGGED-IN COMPANY PROFILE
const updateMyCompany = async (req, res) => {
  try {
    const company = await Company.findOneAndUpdate(
      {
        ownerId: req.user.id,
      },
      {
        companyName: req.body.companyName,
        description: req.body.description,
        website: req.body.website,
        industry: req.body.industry,
        location: req.body.location,
      },
      {
        new: true,
      },
    );

    if (!company) {
      return res.status(404).json({
        message: "Company profile not found",
      });
    }

    res.status(200).json({
      message: "Company profile updated",
      company,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

module.exports = {
  getMyCompany,
  updateMyCompany,
};
