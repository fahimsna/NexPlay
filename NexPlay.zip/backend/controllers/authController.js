const User = require("../models/User");
const Company = require("../models/Company");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// =======================
// Register User / Company
// =======================
const register = async (req, res) => {
  try {
    const {
      fullName,
      username,
      email,
      password,
      role,
      companyName,
      industry,
      website,
      description,
      location,
    } = req.body;

    // Check existing email
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(400).json({
        message: "User already exists",
      });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create User
    const user = await User.create({
      fullName,
      username,
      email,
      password: hashedPassword,
      role: role || "user",
    });

    // If company account create company profile
    if (role === "company") {
      if (!companyName) {
        return res.status(400).json({
          message: "Company name is required",
        });
      }

      const company = await Company.create({
        ownerId: user._id,

        companyName,

        industry,

        website,

        description,

        location,
      });

      return res.status(201).json({
        message: "Company registration successful",

        user: {
          id: user._id,
          fullName: user.fullName,
          username: user.username,
          email: user.email,
          role: user.role,
        },

        company: {
          id: company._id,
          companyName: company.companyName,
          status: company.status,
        },
      });
    }

    // Normal User response
    res.status(201).json({
      message: "Registration successful",

      user: {
        id: user._id,
        fullName: user.fullName,
        username: user.username,
        email: user.email,
        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// =======================
// Login User
// =======================
const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({
        message: "Invalid email or password",
      });
    }

    const isMatch = await bcrypt.compare(password, user.password);

    if (!isMatch) {
      return res.status(400).json({
        message: "Invalid email or password",
      });
    }

    const token = jwt.sign(
      {
        id: user._id,
        role: user.role,
      },

      process.env.JWT_SECRET,

      {
        expiresIn: "7d",
      },
    );

    res.status(200).json({
      message: "Login successful",

      token,

      user: {
        id: user._id,

        fullName: user.fullName,

        username: user.username,

        email: user.email,

        role: user.role,
      },
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

module.exports = {
  register,
  login,
};
