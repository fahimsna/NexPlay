import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import axios from "../../api/axiosInstance";

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post("/auth/login", {
        email,
        password,
      });

      localStorage.setItem("token", response.data.token);

      localStorage.setItem("user", JSON.stringify(response.data.user));

      if (response.data.user.role === "company") {
        navigate("/company");
      } else {
        navigate("/");
      }
    } catch (error) {
      console.log(error.response?.data || error.message);

      alert(error.response?.data?.message || "Login failed");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0B0D10]">
      <div className="w-full max-w-md bg-[#1B1D22] p-8 rounded-3xl border border-white/10">
        <h1 className="text-3xl font-bold text-white text-center mb-8">
          Login
        </h1>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="text-gray-300 text-sm">Email</label>

            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter email"
              className="mt-2 w-full px-4 py-3 rounded-xl bg-white/10 text-white outline-none border border-white/10"
              required
            />
          </div>

          <div>
            <label className="text-gray-300 text-sm">Password</label>

            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter password"
              className="mt-2 w-full px-4 py-3 rounded-xl bg-white/10 text-white outline-none border border-white/10"
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#D4A017] text-black font-bold py-3 rounded-xl hover:opacity-90"
          >
            Login
          </button>
        </form>

        <p className="text-center text-gray-400 mt-6">
          Don't have an account?
          <Link to="/register" className="text-[#D4A017] ml-2 font-semibold">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Login;
