import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

import StatsCard from "../../components/dashboard/StatsCard";
import RecentActivity from "../../components/dashboard/RecentActivity";

import CompanyInfoCard from "../../components/company/CompanyInfoCard";

import {
  HiBuildingOffice2,
  HiMegaphone,
  HiRocketLaunch,
  HiFilm,
} from "react-icons/hi2";

import { getMyCompany } from "../../services/companyService";
function readStoredArray(key) {
  try {
    const savedValue = localStorage.getItem(key);

    if (!savedValue) {
      return [];
    }

    const parsedValue = JSON.parse(savedValue);

    return Array.isArray(parsedValue) ? parsedValue : [];
  } catch (error) {
    console.error(`Could not read ${key}:`, error);

    return [];
  }
}

function CompanyDashboard() {
  const [company, setCompany] = useState(null);

  const [loading, setLoading] = useState(true);

  const [advertisementCount, setAdvertisementCount] = useState(0);

  const [campaignCount, setCampaignCount] = useState(0);

  useEffect(() => {
    fetchCompany();

    updateDashboardCounts();

    window.addEventListener("dashboardDataChanged", updateDashboardCounts);

    return () => {
      window.removeEventListener("dashboardDataChanged", updateDashboardCounts);
    };
  }, []);

  const updateDashboardCounts = () => {
    const advertisements = readStoredArray("nexplayAdvertisements");

    const campaigns = readStoredArray("nexplayCampaigns");

    const activeAdvertisements = advertisements.filter(
      (advertisement) =>
        String(advertisement.status).trim().toLowerCase() === "active",
    );

    const activeCampaigns = campaigns.filter(
      (campaign) => String(campaign.status).trim().toLowerCase() === "active",
    );

    setAdvertisementCount(activeAdvertisements.length);

    setCampaignCount(activeCampaigns.length);
  };

  const fetchCompany = async () => {
    try {
      const data = await getMyCompany();

      setCompany(data.company || data);
    } catch (error) {
      console.log(
        "Error fetching company:",
        error.response?.data || error.message,
      );
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0F1115] flex items-center justify-center">
        <h2 className="text-white text-xl font-semibold">
          Loading Dashboard...
        </h2>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}

      <div>
        <h1 className="text-3xl sm:text-4xl font-black text-white">
          Company Dashboard
        </h1>

        <p className="text-gray-400 mt-2">
          Welcome back{" "}
          <span className="text-[#D4A017] font-semibold">
            {company?.companyName || "Company"}
          </span>
        </p>
      </div>

      {/* Stats */}

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
        <StatsCard
          title="Company Profile"
          value="100%"
          subtitle="Profile Completed"
        />

        <Link
          to="/company/advertisements"
          className="block rounded-3xl transition hover:-translate-y-1"
        >
          <StatsCard
            title="Advertisements"
            value={advertisementCount}
            subtitle="Active Advertisements"
          />
        </Link>

        <Link
          to="/company/campaigns"
          className="block rounded-3xl transition hover:-translate-y-1"
        >
          <StatsCard
            title="Campaigns"
            value={campaignCount}
            subtitle="Running Campaigns"
          />
        </Link>

        <StatsCard
          title="Upcoming Content"
          value="0"
          subtitle="Scheduled Releases"
        />
      </div>

      {/* Company Info */}

      {company && <CompanyInfoCard company={company} />}

      {/* Bottom Section */}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        <RecentActivity company={company} />

        <div className="bg-[#1B1D22] border border-white/10 rounded-3xl p-6 sm:p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white">Quick Actions</h2>

            <p className="text-gray-400 text-sm mt-1">
              Manage your company activities
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <ActionCard
              title="Edit Company"
              description="Update company profile information"
              path="/company/profile"
              icon={HiBuildingOffice2}
            />

            <ActionCard
              title="Create Advertisement"
              description="Promote movies, shows and content"
              path="/company/advertisements"
              icon={HiMegaphone}
            />

            <ActionCard
              title="Create Campaign"
              description="Manage marketing campaigns"
              path="/company/campaigns"
              icon={HiRocketLaunch}
            />

            <ActionCard
              title="Add Content"
              description="Manage upcoming releases"
              path="/company/content"
              icon={HiFilm}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function ActionCard({ title, description, path, icon: Icon }) {
  return (
    <Link
      to={path}
      className="
      bg-[#111318]
      border
      border-white/10
      rounded-2xl
      p-5
      flex
      gap-4
      items-start
      hover:border-[#D4A017]
      transition
      "
    >
      <div className="text-[#D4A017] text-3xl">
        <Icon />
      </div>

      <div>
        <h3 className="text-white font-semibold">{title}</h3>

        <p className="text-gray-400 text-sm mt-2 leading-5">{description}</p>
      </div>
    </Link>
  );
}

export default CompanyDashboard;
