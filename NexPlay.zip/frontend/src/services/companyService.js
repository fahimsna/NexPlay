import axios from "axios";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

const authHeader = () => ({
  headers: {
    Authorization: `Bearer ${localStorage.getItem("token")}`,
  },
});

// ======================
// Get Logged-in Company
// ======================
export const getMyCompany = async () => {
  const res = await axios.get(`${API}/api/company/profile`, authHeader());

  return res.data.company;
};

// ======================
// Update Logged-in Company
// ======================
export const updateMyCompany = async (formData) => {
  const res = await axios.put(`${API}/api/company/profile`, formData, {
    headers: {
      Authorization: `Bearer ${localStorage.getItem("token")}`,
      "Content-Type": "multipart/form-data",
    },
  });

  return res.data.company;
};
